# Descrições Shopify API

API para geração automática de descrições de produtos para lojas Shopify usando IA.

## Funcionalidades

- Integração com Shopify
- Geração de descrições usando IA
- Interface administrativa
- Gerenciamento de produtos

## Tecnologias

- Node.js
- React
- Supabase
- OpenAI
- Shopify API